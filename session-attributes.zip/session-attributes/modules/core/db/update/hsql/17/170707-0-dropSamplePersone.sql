drop table SAMPLE_PERSONE cascade ;
