package com.company.sample.listener;

import com.haulmont.chile.core.datatypes.impl.IntegerDatatype;
import com.haulmont.cuba.core.EntityManager;
import com.haulmont.cuba.core.app.UniqueNumbersAPI;
import com.haulmont.cuba.core.global.Metadata;
import com.haulmont.cuba.core.listener.AfterInsertEntityListener;
import com.haulmont.cuba.core.listener.AfterUpdateEntityListener;
import com.haulmont.cuba.core.listener.BeforeInsertEntityListener;
import com.haulmont.cuba.core.listener.BeforeUpdateEntityListener;
import com.haulmont.cuba.security.entity.Group;
import com.haulmont.cuba.security.entity.SessionAttribute;
import org.springframework.stereotype.Component;

import javax.inject.Inject;
import java.sql.Connection;

@Component("sample_GroupEntityListener")
public class GroupEntityListener implements
        BeforeInsertEntityListener<Group>, AfterInsertEntityListener<Group>,
        BeforeUpdateEntityListener<Group>, AfterUpdateEntityListener<Group> {

    public static final String NAME = "sample_GroupEntityListener";

    @Inject
    private Metadata metadata;
    @Inject
    private UniqueNumbersAPI uniqueNumbers;

    @Override
    public void onBeforeInsert(Group entity, EntityManager entityManager) {

        SessionAttribute sessionAttribute = metadata.create(SessionAttribute.class);
        sessionAttribute.setName("someNumber");
        sessionAttribute.setStringValue(Long.toString(uniqueNumbers.getNextNumber(GroupEntityListener.NAME)));
        sessionAttribute.setDatatype(IntegerDatatype.NAME);
        sessionAttribute.setGroup(entity);

        entityManager.persist(sessionAttribute);

        System.out.println("***** onBeforeInsert *****");
    }

    @Override
    public void onAfterInsert(Group entity, Connection connection) {
        System.out.println("***** onAfterInsert *****");
    }

    @Override
    public void onBeforeUpdate(Group entity, EntityManager entityManager) {
        System.out.println("***** onBeforeUpdate *****");
    }

    @Override
    public void onAfterUpdate(Group entity, Connection connection) {
        System.out.println("***** onAfterUpdate *****");
    }
}